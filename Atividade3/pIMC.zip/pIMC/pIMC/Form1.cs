﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            
            if (!double.TryParse(txtPeso.Text, out peso) || peso <= 0)
            {
                MessageBox.Show("Informe um peso válido");
                txtPeso.Focus();
            }

            if (!double.TryParse(txtAltura.Text, out altura) && altura <= 0)
            {
                MessageBox.Show("Digite uma altura válida");
                txtAltura.Focus();
            }
            
            if (double.TryParse(txtPeso.Text, out peso) && double.TryParse(txtAltura.Text, out altura))
            {
                imc = peso / Math.Pow(altura, 2);
                if (imc < 18.5)
                {
                    MessageBox.Show("Magreza");
                }
                else if (imc >= 18.5 && imc <= 24.9)
                {
                    MessageBox.Show("Normal");
                }
                else if(imc > 24.9 && imc <= 29.9)
                {
                    MessageBox.Show("Sobrepeso");
                }
                else if(imc > 29.9 && imc < 39.9)
                {
                    MessageBox.Show("Obesidade");
                }
                
                
                else if (imc > 39.9)
                {
                    MessageBox.Show("Obesidade Classe III");
                }


            }
        }

        private void TxtAltura_Validated(object sender, EventArgs e)
        {
            if (double.TryParse(txtAltura.Text, out altura) && altura <= 0)
            {
                MessageBox.Show("Informe uma altura válida");
            }
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();

        }

        private void TxtPeso_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso) && peso <= 0)
            {
                MessageBox.Show("Informe um valor válido");
            }
        }
    }
}
