﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btnverif_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[10, 4];
            double[,] totalsem = new double[4,10];
            double[] totalmes = new double [10];
            double totalgeral = 0;
            string aux;
            int i, j;

            for(i = 0; i<10;i++)
            {
                for(j = 0; j<4;j++)
                {
                    aux = Interaction.InputBox("Digite os valores da venda","Entrada de dados");
                    if(!double.TryParse(aux,out vendas[i,j]))
                    {
                        MessageBox.Show("Digite um valor válido");
                        j--;
                    }
                    else
                    {
                        totalsem[j,i] = vendas[i, j];
                        totalmes[i] += vendas[i, j];

                    }
                }
                        totalgeral += totalmes[i];
            }
            for(i=0;i<10; i++)
            {
                for(j=0;j<4;j++)
                {
                    lstvendas.Items.Add("Total mes " + (i + 1) + " Semana " + (j + 1) +": " + totalsem[j, i].ToString("C"));
                }
                    lstvendas.Items.Add("Total mes: " + totalmes[i].ToString("C"));
                lstvendas.Items.Add("-------------------------------");

            }
            lstvendas.Items.Add("Total Geral: " + totalgeral.ToString("C"));

        }
    }
}
