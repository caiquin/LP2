﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumericos_Click(object sender, EventArgs e)
        {
            int Cont = 0;

            for (int i = 0; i < rtxtTexto.Text.Length; i++)
            {
                if (Char.IsNumber(rtxtTexto.Text[i]))
                {
                    Cont++;

                }
            }

            MessageBox.Show(Cont.ToString());
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            
            int i = 0,cont= 0;
            while (i < rtxtTexto.TextLength)
            {
                if (char.IsWhiteSpace(rtxtTexto.Text[i]))
                {
                    break;
                }
                else
                {

                    cont++;
                    i++;
                }

            }
            cont += 1;
            MessageBox.Show("A primeiro espaço em branco está na posição: " + cont.ToString());
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int cont = 0;

            foreach(char c in rtxtTexto.Text)
            {
                if (Char.IsLetter(c))
                {
                    cont++;
                }
            }
            MessageBox.Show(cont.ToString());
        }
    }
 }

