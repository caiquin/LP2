﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void BtnInstanciar_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHoras.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFalta.Text);

            if (rbtnSim.Checked)
                objHorista.HomeOffice = 'S';
            else
                objHorista.HomeOffice = 'N';

            MessageBox.Show("Matricula: " + objHorista.Matricula + "\n" + "Nome: " + objHorista.NomeEmpregado + "\n" + "Data Entrada: " + objHorista.DataEntradaEmpresa.ToShortDateString() + "\n" + "Salário: " + objHorista.SalarioHora.ToString("N2") + "\n" + "Dias falta; " + objHorista.DiasFalta + '\n' + "Número Horas: " + objHorista.NumeroHora +  "Tempo Empresa(dias): " + objHorista.TempoTrabalho() + '\n' + objHorista.VerficiaHome());
        }
    }
}
