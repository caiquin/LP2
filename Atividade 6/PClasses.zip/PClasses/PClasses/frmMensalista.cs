﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void FrmMensalista_Load(object sender, EventArgs e)
        {

        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Mensalista objMenslista = new Mensalista();

            objMenslista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMenslista.NomeEmpregado = txtNome.Text;
            objMenslista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objMenslista.SalarioMensal = Convert.ToDouble(txtSalMensal.Text);

            if (rbtnSim.Checked)
                objMenslista.HomeOffice = 'S';
            else
                objMenslista.HomeOffice = 'N';

            MessageBox.Show("Matricula: " + objMenslista.Matricula + "\n" + "Nome: " + objMenslista.NomeEmpregado + "\n" + "Data Entrada: " + objMenslista.DataEntradaEmpresa.ToShortDateString() + "\n" + "Salário Bruto: " + objMenslista.SalarioBruto().ToString("N2") + "\n" + "Tempo Empresa(dias): " + objMenslista.TempoTrabalho() + '\n' + objMenslista.VerficiaHome());
        }

        private void BtnInstanciar2_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(Convert.ToInt32(txtMatricula.Text), txtNome.Text,
            Convert.ToDateTime(txtData.Text),
            Convert.ToDouble(txtSalMensal.Text));

            MessageBox.Show("Matricula: " + objMensalista.Matricula + "\n" + "Nome: " + objMensalista.NomeEmpregado + "\n" + "Data Entrada: " + objMensalista.DataEntradaEmpresa.ToShortDateString() + "\n" + "Salário Bruto: " + objMensalista.SalarioBruto().ToString("N2") + "\n" + "Tempo Empresa(dias): " + objMensalista.TempoTrabalho() + '\n' + objMensalista.VerficiaHome());

        }
    }
}
