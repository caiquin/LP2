﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pSalariou
{
    public partial class Form1 : Form
    {
        double salarioBruto, salarioLiquido, salarioFam, descontoINSS, descontoIRPF;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSalBruto.Text, out salarioBruto) && salarioBruto <= 0)
            {
                MessageBox.Show("Informe um salário válido");
            }
            else
            {
                if (salarioBruto <= 800.47)
                {
                    txtAliqINSS.Text = "7,65%";
                    descontoINSS = 0.0765 * salarioBruto;
                    txtDescINSS.Text = descontoINSS.ToString();
                }
                else if (salarioBruto <= 1050)
                {
                    txtAliqINSS.Text = "8,65%";
                    descontoINSS = 0.0865 * salarioBruto;
                    txtDescINSS.Text = descontoINSS.ToString();
                }
                else if (salarioBruto <= 1400.77)
                {
                    txtAliqINSS.Text = "9,00%";
                    descontoINSS = 0.09 * salarioBruto;
                    txtDescINSS.Text = descontoINSS.ToString();
                }
                else if (salarioBruto <= 2801.56)
                {
                    txtAliqINSS.Text = "11,00%";
                    descontoINSS = 0.11 * salarioBruto;
                    txtDescINSS.Text = descontoINSS.ToString();
                }
                else
                {
                    txtAliqINSS.Text = "Teto";
                    descontoINSS = 308.17;
                    txtDescINSS.Text = descontoINSS.ToString();
                }



                if (salarioBruto < 1257.13)
                {
                    txtAliqIRPF.Text = "Isento";
                    descontoIRPF = 0;
                    txtDescIRPF.Text = descontoIRPF.ToString();
                }
                else if (salarioBruto <= 2512.08)
                {
                    txtAliqIRPF.Text = "15,00%";
                    descontoIRPF = 0.15 * salarioBruto;
                    txtDescIRPF.Text = descontoIRPF.ToString();
                }
                else
                {
                    txtAliqIRPF.Text = "27,50%";
                    descontoIRPF = 0.275 * salarioBruto;
                    txtDescIRPF.Text = descontoIRPF.ToString();
                }



                if(salarioBruto <= 435.52)
                {
                    salarioFam = ((int)nudFilhos.Value) * 22.33;
                    txtSalFam.Text = salarioFam.ToString();
                }
                else if(salarioBruto <= 654.61)
                {
                    salarioFam = ((int)nudFilhos.Value) * 15.74;
                    txtSalFam.Text = salarioFam.ToString();
                }
                else
                {
                    salarioFam = 0;
                    txtSalFam.Text = salarioFam.ToString();
                }



                salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFam;
                txtSalLiq.Text = salarioLiquido.ToString();


                if (rbtnFem.Checked)
                {
                    if (ckbxCasado.Checked)
                    {
                        lblDados.Text = "Esses são os descontos da "+ txtNome.Text+", é Casada e possui " + (int)nudFilhos.Value + " filho(s)";
                    }
                    else
                    {
                        lblDados.Text = "Esses são os descontos da " + txtNome.Text + " é solteira e possui " + (int)nudFilhos.Value + " filho(s)";
                    }
                 }
                else
                {
                    if (ckbxCasado.Checked)
                    {
                        lblDados.Text = "Esses são os descontos do " + txtNome.Text + ", é Casado e possui " + (int)nudFilhos.Value + " filho(s)";
                    }
                    else
                    {
                        lblDados.Text = "Esses são os descontos do " + txtNome.Text + ", é solteiro e possui " + (int)nudFilhos.Value + " filho(s)";
                    }
                }
                }

            }
        }
   }


