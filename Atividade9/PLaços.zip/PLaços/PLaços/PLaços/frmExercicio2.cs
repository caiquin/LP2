﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLaços
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double n, h = 0;
            if(double.TryParse(txtNum.Text, out n) || n > 0)
            {
                for(var i = 0; i < n ; i++)
                {
                    h = 1.0f / (i + 2);
                }

                MessageBox.Show("O número H é: " + h);

            }
            else
                MessageBox.Show("Digite um número válido");
        }

        private void frmExercicio2_Load(object sender, EventArgs e)
        {

        }
    }
}
