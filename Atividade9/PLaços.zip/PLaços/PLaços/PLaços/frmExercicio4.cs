﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLaços
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Salario = Double.Parse(txtSalario.Text);
            double Producao = Double.Parse(txtProducao.Text);
            double Gratificacao = Double.Parse(txtGrati.Text);
            int B = 0, C = 0, D = 0;
            double A = 0;

            A = Salario;

            if (Producao >= 100)
                B = 1;
            if (Producao >= 120)
                C = 1;
            if (Producao >= 150)
                D = 1;


            Salario = A + A * ((0.05 * B) + (0.1 * C) + (0.1 * D)) + Gratificacao;

            MessageBox.Show("O salário bruto a ser pago é: " + Salario.ToString());
        }
    }
}
