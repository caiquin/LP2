﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLaços
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void BtnEspacoBranco_Click(object sender, EventArgs e)
        {
            int cont = 0;

            foreach(char c in rtxtFrase.Text)
            {
                if (char.IsWhiteSpace(c))
                {
                    cont++;
                }
            }
            MessageBox.Show("O número de espaços em branco é: " + cont);
        }

        private void BrnPares_Click(object sender, EventArgs e)
        {
            char letraAnterior = '\0';
            int numPares = 0;
            for (var i = 0; i < rtxtFrase.TextLength; i++)
            {

                if (rtxtFrase.Text[i] == letraAnterior)
                {
                    numPares++;
                }
               letraAnterior = rtxtFrase.Text[i];
            }

            MessageBox.Show("Númeor de pares de letras é : " + numPares);
        }

        private void BtnLetraR_Click(object sender, EventArgs e)
        {
            int cont = 0;
            char letra = 'R';
            for (var i = 0; i < rtxtFrase.TextLength; i++) 
            {
                if(rtxtFrase.Text[i] == 'R' || rtxtFrase.Text[i] == 'r')
                {
                    cont++;
                }

            }

            MessageBox.Show("O número de letras R é: " + cont);
        }
    }
}
