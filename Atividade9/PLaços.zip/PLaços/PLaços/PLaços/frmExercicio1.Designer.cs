﻿namespace PLaços
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.brnPares = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtxtFrase
            // 
            this.rtxtFrase.Location = new System.Drawing.Point(72, 52);
            this.rtxtFrase.Name = "rtxtFrase";
            this.rtxtFrase.Size = new System.Drawing.Size(631, 96);
            this.rtxtFrase.TabIndex = 0;
            this.rtxtFrase.Text = "";
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.Location = new System.Drawing.Point(37, 270);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(205, 60);
            this.btnEspacoBranco.TabIndex = 1;
            this.btnEspacoBranco.Text = "Espaços em Branco";
            this.btnEspacoBranco.UseVisualStyleBackColor = true;
            this.btnEspacoBranco.Click += new System.EventHandler(this.BtnEspacoBranco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(285, 270);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(205, 60);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Letra R";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.BtnLetraR_Click);
            // 
            // brnPares
            // 
            this.brnPares.Location = new System.Drawing.Point(546, 270);
            this.brnPares.Name = "brnPares";
            this.brnPares.Size = new System.Drawing.Size(205, 60);
            this.brnPares.TabIndex = 3;
            this.brnPares.Text = "Pares";
            this.brnPares.UseVisualStyleBackColor = true;
            this.brnPares.Click += new System.EventHandler(this.BrnPares_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.brnPares);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.rtxtFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtFrase;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button brnPares;
    }
}