﻿namespace PLaços
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVeriPali = new System.Windows.Forms.Button();
            this.txtPali = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnVeriPali
            // 
            this.btnVeriPali.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVeriPali.Location = new System.Drawing.Point(321, 236);
            this.btnVeriPali.Name = "btnVeriPali";
            this.btnVeriPali.Size = new System.Drawing.Size(164, 68);
            this.btnVeriPali.TabIndex = 4;
            this.btnVeriPali.Text = "Verificar Palíndromo";
            this.btnVeriPali.UseVisualStyleBackColor = true;
            this.btnVeriPali.Click += new System.EventHandler(this.btnVeriPali_Click);
            // 
            // txtPali
            // 
            this.txtPali.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPali.Location = new System.Drawing.Point(211, 146);
            this.txtPali.Name = "txtPali";
            this.txtPali.Size = new System.Drawing.Size(378, 26);
            this.txtPali.TabIndex = 3;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnVeriPali);
            this.Controls.Add(this.txtPali);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVeriPali;
        private System.Windows.Forms.TextBox txtPali;
    }
}