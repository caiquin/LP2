﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTriangulo
{
    public partial class Form1 : Form
    {
        double lado1,lado2,lado3;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtVal1.Clear();
            txtVal2.Clear();
            txtVal3.Clear();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtVal1.Text, out lado1) || lado1 <= 0)
            {
                MessageBox.Show("Informe um valor válido no primeiro lado");
                txtVal1.Focus();
            }
            if (!double.TryParse(txtVal2.Text, out lado2) || lado2 <= 0)
            {
                MessageBox.Show("Informe um valor válido no segundo lado");
                txtVal2.Focus();
            }
            if (!double.TryParse(txtVal3.Text, out lado3) || lado3 <= 0)
            {
                MessageBox.Show("Informe um valor válido no tercerio lado");
                txtVal3.Focus();
            }

            if(double.TryParse(txtVal1.Text, out lado1) && double.TryParse(txtVal2.Text, out lado2) && double.TryParse(txtVal3.Text, out lado3))
            {
                if (lado1 < (lado2 + lado3) && lado1 > Math.Abs(lado2 - lado3) && lado2 < (lado1 + lado3) && lado2 > Math.Abs(lado1 - lado3) && lado3 < (lado1 + lado2) && lado3 > Math.Abs(lado1 - lado2))
                {
                    if(lado1 == lado2 && lado2 == lado3)
                    {
                        MessageBox.Show("Este triângulo é Equilátero");
                    }
                    else if(lado1 == lado2 || lado1 == lado3 || lado3 == lado2)
                    {
                        MessageBox.Show("Este triângulo é Isóceles");
                    }
                    else if(lado1 != lado2 && lado2 != lado3)
                    {
                        MessageBox.Show("Este triângulo é Escaleno");
                    }
                }
                else
                {
                    MessageBox.Show("Não é triângulo");
                }
            }
            

        }
    }
}
